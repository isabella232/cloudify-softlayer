class SetupDb2
  @queue = :bootstrap

  def self.perform node
    # Ensure 'node' hash uses symbols as keys
    node = node.deep_symbolize_keys

    Rails.logger.info %x(
      # Start OpenLDAP
      service slapd start
      # Even though the service invocation returns, slapd isn't quite ready to
      # rock yet. Take a nap.
      sleep 60

      # Start DB2 and DAS
      su - #{node[:db2][:das][:username]} -c "db2admin start"
      su - #{node[:db2][:instance][:username]} -c "db2start"

      # Configure DB2 memory
      su - #{node[:db2][:instance][:username]} -c "\
        /bin/bash #{Rails.root}/vendor/scripts/config_db2_memory.sh apply"

      # Stop DB2 and DAS
      su - #{node[:db2][:instance][:username]} -c "db2stop force"
      su - #{node[:db2][:das][:username]} -c "db2admin stop"

      # Stop OpenLDAP
      service slapd stop
      sleep 10
    )
  end
end
