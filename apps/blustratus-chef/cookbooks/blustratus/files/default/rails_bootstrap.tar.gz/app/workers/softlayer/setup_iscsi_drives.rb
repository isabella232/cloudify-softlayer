class Softlayer::SetupIscsiDrives
  @queue = :bootstrap

  def self.perform username, access_key, size
    return if size < 1033 || size > 1046

    data_device = SoftlayerBootstrapScripts.order(username, access_key, size)

    iscsi_user = data_device["username"]
    iscsi_password = data_device["password"]
    iscsi_ip = data_device["serviceResourceBackendIpAddress"]
    `bash #{Rails.root}/vendor/scripts/connect_iscsi.sh #{iscsi_user} #{iscsi_password} #{iscsi_ip}`

    `mv /mnt/bludata0/db2 /tmp/db2`

    drives = [{
      username: data_device["username"],
      mount_dir: '/mnt/bludata0',
      format: true
    }]
    SoftlayerBootstrapScripts.mount_drives drives

    `mv /tmp/db2 /mnt/bludata0`
  end
end