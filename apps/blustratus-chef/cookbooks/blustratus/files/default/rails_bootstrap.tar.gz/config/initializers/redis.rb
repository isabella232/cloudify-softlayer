redis_conf = Rails.root.join("config/redis", "#{Rails.env}.conf")
`redis-server #{redis_conf}`
$redis = Redis.new(:host => 'localhost', :port => 6379)