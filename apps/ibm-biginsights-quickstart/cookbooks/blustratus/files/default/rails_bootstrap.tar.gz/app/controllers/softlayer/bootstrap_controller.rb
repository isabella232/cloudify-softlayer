class Softlayer::BootstrapController < ApplicationController
  before_filter :validate_session, :authenticate_key, :authenticate_license,
                :authenticate_credentials, :check_step, :check_running

  skip_before_filter :validate_session, only: ['index', 'logout']
  skip_before_filter :authenticate_key, only: ['index', 'auth', 'logout']
  skip_before_filter :authenticate_license, only: ['index', 'auth', 'license', 'logout']
  skip_before_filter :authenticate_credentials, only: ['index', 'auth', 'license', 'sl_config', 'logout']
  skip_before_filter :check_step, only: ['index', 'run', 'logout']
  skip_before_filter :check_running, only: ['index', 'logout']

  STORAGE_OPTIONS = {
    "20 GB" => 1033,
    "40 GB" => 1034,
    "80 GB" => 1035,
    "100 GB" => 1036,
    "120 GB" => 1037,
    "200 GB" => 1038,
    "250 GB" => 1039,
    "300 GB" => 1040,
    "350 GB" => 1041,
    "430 GB" => 1042,
    "450 GB" => 1043,
    "500 GB" => 1044,
    "700 GB" => 1045,
    "1000 GB" => 1046
  }

  def index
    if params[:back]
      $redis.set('current_step', 'index')
      return
    end

    if request.post?
      current_step = $redis.get('current_step')
      current_step ||= 'index'

      unless current_step == 'index'
        redirect_to action: current_step
        return
      end

      $redis.set('current_step', 'auth')
      redirect_to action: 'auth'
    end
  end

  def auth
    if params[:back]
      $redis.set('current_step', 'auth')
      return
    end

    if request.post?
      begin
        Net::SSH.start('localhost', 'root', password: params[:password])

        session[:authenticated] = true

        $redis.set('current_step', 'license')
        redirect_to action: 'license'
      rescue Net::SSH::AuthenticationFailed
        flash[:error] = "Authentication failed. Please try again."
      end
    end
  end

  def license
    license_dir = Rails.root.join('vendor', 'assets', 'licenses')
    db2_license_path = File.join(license_dir, t('bootstrap.license.db2_license_file'))

    File.open(db2_license_path, "r") do |f|
      @db2_license = f.read
    end

    @license_accepted = $redis.get('license_accepted')

    if params[:back]
      $redis.set('current_step', 'license')
      return
    end

    if request.post?
      if params[:license_action] == 'accepted'
        $redis.set('license_accepted', true)

        `/bin/sh #{Rails.root}/vendor/scripts/updatesshdcfg.sh`
        `/etc/init.d/sshd restart`

        $redis.set('current_step', 'sl_config')
        redirect_to action: 'sl_config'
      elsif params[:license_action] == 'declined'
        `halt -f -p`
      end
    end
  end

  def sl_config
    if params[:back]
      $redis.set('current_step', 'sl_config')
      return
    end

    if request.post?

      if params[:username].blank? || params[:access_key].blank?
        flash[:error] = t('softlayer.bootstrap.sl_config.error.cant_be_blank')

      else
        session[:username] = params[:username]
        session[:access_key] = params[:access_key]

        $redis.set('current_step', 'storage_config')
        redirect_to action: 'storage_config'
      end
    end
  end

  def storage_config
    if params[:back]
      Resque.dequeue(Softlayer::SetupIscsiDrives)
      Resque.dequeue(SetupOsUser)
      Resque.dequeue(SetupServices)
      Resque.dequeue(SetupDb2)
      $redis.set('current_step', 'storage_config')
      return
    end

    if request.post?
      case params[:storage_option]
        when 'new'
          $redis.set('current_step', 'create_storage')
          redirect_to action: 'create_storage'
        when 'local'
          $redis.set('current_step', 'db2_config')
          redirect_to action: 'db2_config'
        else
          flash[:error] = t('softlayer.bootstrap.storage_config.error.select_device_type')
      end
    end
  end

  def create_storage
    @storage_options = STORAGE_OPTIONS

    if params[:back]
      $redis.set('current_step', 'create_storage')
      return
    end

    if request.post?
      Resque.enqueue(Softlayer::SetupIscsiDrives, session[:username], session[:access_key], params[:size].to_i)

      $redis.set('current_step', 'db2_config')
      redirect_to action: 'db2_config'
    end
  end

  def db2_config
    if params[:back]
      Resque.dequeue(SetupOsUser)
      Resque.dequeue(SetupServices)
      Resque.dequeue(SetupDb2)
      $redis.set('current_step', 'db2_config')
      return
    end

    if request.post?
      if [params[:password], params[:password_confirmation]].any? { |p| p.blank? }
        flash[:error] = t('bootstrap.db2_config.error.missing_inputs')

      elsif params[:password] != params[:password_confirmation]
        flash[:error] = t('bootstrap.db2_config.error.non_matching_password')

      else
        # Get bootstrap config
        node = BluBootstrap::Application.config.bootstrap
        node[:console][:password] = params[:password]
        node[:ldap][:password] = params[:password]
        node[:db2][:instance][:password] = params[:password]

        # OS-authenticating users
        Resque.enqueue(SetupOsUser, node[:db2][:instance][:username], params[:password])
        Resque.enqueue(SetupOsUser, node[:db2][:fenced][:username], params[:password])
        Resque.enqueue(SetupOsUser, node[:db2][:das][:username], params[:password])

        Resque.enqueue(SetupServices, params[:password], node)

        Resque.enqueue(SetupDb2, node)

        $redis.set('current_step', 'register')
        redirect_to action: 'register'
      end
    end
  end

  def register
    @first_name = $redis.get('register_first_name')
    @last_name = $redis.get('register_last_name')
    @email = $redis.get('register_email')
    @company = $redis.get('register_company')
    @contact_email = $redis.get('register_contact_email') == 'true'
    @contact_telephone = $redis.get('register_contact_telephone') == 'true'
    @contact_postal = $redis.get('register_contact_postal') == 'true'
    @agree = $redis.get('register_agree').blank? || $redis.get('register_agree') == 'true'

    if params[:back]
      $redis.set('current_step', 'register')
      return
    end

    if request.post?

      @first_name = params[:first_name]
      @last_name = params[:last_name]
      @email = params[:email]
      @company = params[:company]
      @contact_email = params[:contact_email] == 'true'
      @contact_telephone = params[:contact_telephone] == 'true'
      @contact_postal = params[:contact_postal] == 'true'
      @agree = params[:agree] == 'true'

      $redis.set('register_agree', @agree)

      if @agree
        if [@first_name, @last_name, @email, @company].any? { |p| p.empty? }
          flash[:error] = "Missing fields"
          return
        end

        $redis.set('register_first_name', @first_name)
        $redis.set('register_last_name', @last_name)
        $redis.set('register_email', @email)
        $redis.set('register_company', @company)
        $redis.set('register_contact_email', @contact_email)
        $redis.set('register_contact_telephone', @contact_telephone)
        $redis.set('register_contact_postal', @contact_postal)
      else
        $redis.del('register_first_name')
        $redis.del('register_last_name')
        $redis.del('register_email')
        $redis.del('register_company')
        $redis.del('register_contact_email')
        $redis.del('register_contact_telephone')
        $redis.del('register_contact_postal')
      end

      $redis.set('current_step', 'apply')
      redirect_to action: 'apply'
    end
  end

  def apply
    jobs = Resque.peek 'bootstrap', 0, Resque.size('bootstrap')
    jobs = [jobs] unless jobs.is_a? Array

    iscsi_drive = jobs.select { |j| j["class"] == "Softlayer::SetupIscsiDrives" }
    os_users = jobs.select { |j| j["class"] == "SetupOsUser" }
    services = jobs.select { |j| j["class"] == "SetupServices" }
    db2 = jobs.select { |j| j["class"] == "SetupDb2" }

    if [os_users, services, db2].any? { |a| a.empty? }
      Resque.remove_queue('bootstrap')
      flash[:error] = t('bootstrap.error.missing_configuration')

      $redis.set('current_step', 'storage_config')
      redirect_to action: 'storage_config'
      return
    end

    @create_iscsi = !iscsi_drive.empty?
    if @create_iscsi
      @iscsi_size = STORAGE_OPTIONS.invert[iscsi_drive.first["args"][2]]
    end

    @password = '*' * services.first["args"].first.size
    @port = BluBootstrap::Application.config.bootstrap[:console][:port]
  end

  def run
    $redis.set('running', true)
    logger.info '>> Start Running...'

    while Resque.size('bootstrap') > 0
      job = Resque.pop('bootstrap')
      logger.info ">> Running job: #{job}"

      begin
        obj = job["class"].constantize
        obj.perform(*job["args"])
      rescue => e
        logger.info e.message
        logger.info e.inspect

        $redis.set('running', false)

        render json: { error: e.message }, status: 500
        return
      end
    end

    $redis.set('current_step', 'done')
    $redis.set('running', false)

    exec("/bin/bash #{Rails.root}/vendor/scripts/start_web_console.sh")
    render text: "OK"
  end

  def done
    port = BluBootstrap::Application.config.bootstrap[:console][:port]
    url = URI.parse(request.original_url)
    @web_console_url = "#{url.scheme}://#{url.host}:#{port}"
  end

private
  def authenticate_credentials
    if [session[:username], session[:access_key]].any? { |s| s.blank? }
      $redis.set('current_step', 'sl_config')
      redirect_to action: 'sl_config'
    end
  end

end
