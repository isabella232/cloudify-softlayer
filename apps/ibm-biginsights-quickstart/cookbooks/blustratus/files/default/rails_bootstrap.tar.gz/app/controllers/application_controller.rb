class ApplicationController < ActionController::Base
  protect_from_forgery
  before_filter :set_locale, :check_cloud_provider

  def index
    case ENV['CLOUD_PROVIDER']
    when 'EC2'
      redirect_to controller: 'amazon/bootstrap', action: 'index'
      return
    when 'SOFTLAYER'
      redirect_to controller: 'softlayer/bootstrap', action: 'index'
      return
    end

    render text: <<-EOH
      <p>ERROR: No cloud service specified in CLOUD_PROVIDER environment variable. Possible values are:</p>
      <ul>
        <li>EC2 (Amazon)</li>
        <li>SOFTLAYER (SoftLayer)</li>
      </ul>
    EOH
  end

  def logout
    session.delete :authenticated
    session.delete :username
    session.delete :access_key

    $redis.del('session_id')
    $redis.del('current_step')

    Resque.remove_queue('bootstrap')

    redirect_to root_path
  end

  def set_locale
    I18n.locale = params[:locale] || I18n.default_locale
  end

  def check_cloud_provider
    puts request.original_url

    if (request.original_url.include?('amazon') && ENV['CLOUD_PROVIDER'] != 'EC2') ||
      (request.original_url.include?('softlayer') && ENV['CLOUD_PROVIDER'] != 'SOFTLAYER')
      raise ActionController::RoutingError.new('Not Found')
    end
  end

  def validate_session
    session_id = request.session_options[:id]
    saved_session_id = $redis.get('session_id')

    if session_id.blank?
      redirect_to action: 'index'
      return
    end

    if saved_session_id.blank?
      $redis.set('session_id', session_id)
      $redis.expire('session_id', 300)
      saved_session_id = session_id
    end

    if session_id != saved_session_id
      flash[:notice] = t('bootstrap.error.configuration_in_process')
      redirect_to action: 'index'
    end
  end

  def authenticate_key
    if !session[:authenticated]
      $redis.set('current_step', 'auth')
      redirect_to action: 'auth'
    end
  end

  def authenticate_license
    if !$redis.get('license_accepted')
      $redis.set('current_step', 'license')
      redirect_to action: 'license'
    end
  end

  def check_step
    current_step = $redis.get('current_step')

    if !current_step
      $redis.set('current_step', 'index')
      redirect_to action: 'index'
      return
    end

    if current_step != params[:action] && !params[:back]
      redirect_to action: current_step
    end
  end

  def check_running
    if $redis.get('running')
      port = BluBootstrap::Application.config.bootstrap[:console][:port]
      url = URI.parse(request.original_url)
      web_console_url = "#{url.scheme}://#{url.host}:#{port}"

      flash[:notice] = t('bootstrap.error.installation_in_process', href: web_console_url).html_safe
      redirect_to action: 'index'
    end
  end
end
