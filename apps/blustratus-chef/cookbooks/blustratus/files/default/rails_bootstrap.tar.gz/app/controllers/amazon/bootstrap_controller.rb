require 'fileutils'

class Amazon::BootstrapController < ApplicationController
  before_filter :is_ready, :authenticate_key, :authenticate_license, :authenticate_credentials

  skip_before_filter :is_ready, only: ['index', 'logout']
  skip_before_filter :authenticate_key, only: ['index', 'key', 'logout']
  skip_before_filter :authenticate_license, only: ['index', 'key', 'license', 'logout']
  skip_before_filter :authenticate_credentials, only: ['index', 'key', 'license', 'aws_config', 'logout']

  def index
    @ready = File.exists? '/var/www/ready'
  end

  def key
    if params[:upload]

      upload_directory = "tmp/uploads"
      FileUtils.mkdir_p(upload_directory) unless File.directory? upload_directory

      file_name = params[:upload][:key].original_filename
      file_path = File.join(upload_directory, file_name)

      begin
        file_content = params[:upload][:key].read
        raise ArgumentError, t('bootstrap.key.private_key.upload_error') if file_content.blank?()

        File.open(file_path, "w") { |file| file.write file_content }

        `./vendor/scripts/key_compare.sh #{file_path}`
        raise ArgumentError, t('bootstrap.key.private_key.no_match') if $?.exitstatus != 0

        session[:authenticated] = true
        redirect_to action: 'license'
      rescue IOError => e
        flash[:error] = t('bootstrap.key.private_key.upload_error')
      rescue ArgumentError => e
        flash[:error] = e.message
      end

    end
  end

  def license
    db2_license_path = File.join("vendor/assets/licenses", t('bootstrap.license.db2_license_file'))
    File.open(db2_license_path, "r") do |f|
      @db2_license = f.read
    end

    if params[:license_action] == 'accepted'
      `touch ./vendor/locks/license_accepted`
      `sudo /bin/sh ./vendor/scripts/updatesshdcfg.sh`
      `sudo /etc/init.d/sshd restart`

      redirect_to action: 'aws_config'
    elsif params[:license_action] == 'declined'
      `sudo halt -f -p`
    end
  end

  def aws_config
    if request.post?
      `rm -f ./vendor/locks/aws_finished`

      session[:access_key] = params[:access_key]
      session[:secret_key] = params[:secret_key]

      if AwsBootstrapScripts.validate_credentials(params[:access_key], params[:secret_key])
        `touch ./vendor/locks/aws_finished`
        redirect_to action: 'ebs_config'
      else
        flash[:error] = t('bootstrap.aws_config.keys_dont_match')
      end
    end
  end

  def ebs_config
    if request.post?
      case params[:ebs_option]
        when 'new'
          redirect_to action: 'create_ebs'
        when 'existing'
          redirect_to action: 'list_ebs'
        when 'local'
          redirect_to action: 'no_ebs'
      end
    end
  end

  def ebs_config_report
    @from = params[:from]
    use_iops = params[:'use-iops'] == '1'

    AwsBootstrapScripts.create_from_snapshot_and_attach_ebs(
      session[:access_key], session[:secret_key],
      size: 10, device: '/dev/xvdh', snapshot_id: 'snap-9837e995')

    AwsBootstrapScripts.mount_ebs(device: '/dev/xvdh', mount_point: '/db2fs', format: false)

    AwsBootstrapScripts.create_and_attach_ebs(
      session[:access_key], params[:secret_key],
      size: params[:size], device: '/dev/xvdg', want_iops: use_iops, iops: params[:iops])

    AwsBootstrapScripts.mount_ebs(device: '/dev/xvdg', mount_point: '/db2fs2', format: true)

    @ebs_list = AwsBootstrapScripts.list_connected_ebs(
      session[:access_key], session[:secret_key], device: '/dev/xvdh,/dev/xvdg')

    `touch ./vendor/locks/ebs_finished` if !@ebs_list.empty?

    dev_list_output = `df -h | grep -E \%./db2fs`
    @dev_list = dev_list_output.split("\n")
  end

  def create_ebs
  end

  def list_ebs
    @ebs_volumes = AwsBootstrapScripts.list_ebs(session[:access_key], session[:secret_key])
  end

  def attach_ebs
    begin
      `rm -f ./vendor/locks/ebs_finished`
      @ebs = AwsBootstrapScripts.attach_ebs(
        session[:access_key], session[:secret_key],
        volume_id: params[:volume_id], device: '/dev/xvdg')

      AwsBootstrapScripts.mount_ebs(device: '/dev/xvdg', mount_point: '/db2fs', format: false)

    rescue => e
      flash[:error] = t('bootstrap.attach_ebs.error.no_attach')
      redirect_to action: 'ebs_config'
    end
  end

  def no_ebs
    `rm -f ./vendor/locks/ebs_finished`
    `umount /dev/sdh >>/tmp/ebs.log 2>&1`
    `mkdir /db2fs`
    `chown db2inst1 /db2fs`

    redirect_to action: 'ebs_config_report'
  end

  def db2_config
    `touch ./vendor/locks/db2_start`
  end

  def config_blu_users
    `sudo ./vendor/scripts/confid_db2_users.sh #{params[:password]} db2iadm1 #{params[:user]}`
    `sudo ./vendor/scripts/confid_db2_users.sh #{params[:password]} db2fadm1  db2fenc1}`
    `sudo ./vendor/scripts/confid_db2_console.sh #{params[:password]} db2iadm1 #{params[:user]} 50001`

    render nothing: true
  end

  def config_cognos
    `sudo ./vendor/scripts/configCognos.sh #{params[:password]} #{params[:user]} &> /dev/null &`

    render nothing: true
  end

  def setup_db2
    `sudo su - db2inst1 -c 'db2 update dbm cfg using  DFTDBPATH "/db2fs"'`
    `sudo su - db2inst1 -c "db2 catalog db metadb"`
    `sudo su - db2inst1 -c "db2 catalog db cm"`
    `sudo su - db2inst1 -c "db2 catalog db cqw_demo"`
    `sudo su - db2inst1 -c 'db2 update dbm cfg using  DFTDBPATH "/db2fs2"'`

    render nothing: true
  end

  def done
  end

  private
  def is_ready
    redirect_to action: 'index' if !File.exists? '/var/www/ready'
  end
  def authenticate_key
    redirect_to action: 'key' if !session[:authenticated]
  end

  def authenticate_license
    redirect_to action: 'license' if !File.exists? './vendor/locks/license_accepted'
  end

  def authenticate_credentials
    redirect_to action: 'aws_config' if !session[:access_key] || !session[:secret_key]
  end
end
