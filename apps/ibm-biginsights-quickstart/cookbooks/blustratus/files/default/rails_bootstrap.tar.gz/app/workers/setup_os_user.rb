class SetupOsUser
  @queue = :bootstrap

  def self.perform user_name, password
    encrypted = password.crypt "$6$#{SecureRandom.urlsafe_base64 8*3/4}"
    Rails.logger.info %x(
      usermod -p "#{encrypted.gsub("$","\\$")}" #{user_name}
      usermod -U #{user_name}
    )
  end
end
