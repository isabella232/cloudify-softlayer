class Amazon::SetupEbsDrives
  @queue = :bootstrap

  def self.perform access_key, secret_key, size, use_iops, iops

    AwsBootstrapScripts.create_and_attach_ebs(access_key, secret_key,
      size: size, device: '/dev/xvdg', want_iops: use_iops, iops: iops)

    `mv /mnt/bludata0/db2 /tmp/db2`

    AwsBootstrapScripts.mount_ebs(device: '/dev/xvdg', mount_point: '/mnt/bludata0', format: true)

    `mv /tmp/db2 /mnt/bludata0`
  end
end