var dialog;

function restrictCharacters(myfield, e, restrictionType) {
	if (!e) e = window.event;
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
	var character = String.fromCharCode(code);

	if (code==27) { this.blur(); return false; }

	if (!e.ctrlKey && code!=9 && code!=8 && code!=36 && code!=37 && code!=38 && (code!=39 || (code==39 && character=="'")) && code!=40) {
		if (character.match(restrictionType)) {
			return true;
		} else {
			return false;
		}
	}
}

function isBlank(str) {
	return (!str || /^\s*$/.test(str));
}

function runQueue(queue) {
	if (queue.length === 0) {
		$('form').submit();
	}

	var command = queue[0];
	dialog.setAttrs({ headerContent: command.message });

	$.post(command.url, command.data, function(data) {
		queue.shift();
		runQueue(queue);
	}).fail(function() {
		dialog.hide();
		alert('Error');
	});
}

function configureDB2() {
	var user = $('#user_name').val();
	var password = $('#password').val();
	var passwordConfirmation = $('#password_confirmation').val();

	if (password !== passwordConfirmation) {
		alert(I18n.bootstrap.db2_config.error.non_matching_password);
		return;
	}

	if (isBlank(password)) {
		alert(I18n.bootstrap.db2_config.error.blank_password);
		return;
	}

	$('#db2-config-next-button').attr('disabled','disabled');
	$('body').addClass('yui3-skin-sam');

	var commandsQueue = [];
	commandsQueue.push(
		{
			url: 'config_blu_users',
			data: {
				user: user,
				password: password
			},
			message: I18n.bootstrap.db2_config.configuring_blu
		},
		{
			url: 'config_cognos',
			data: {
				user: user,
				password: password
			},
			message: I18n.bootstrap.db2_config.configuring_cognos
		},
		{
			url: 'setup_db2',
			message: I18n.bootstrap.db2_config.setting_up_databases
		}
	);

	YUI().use("panel", function (Y) {  // loading escape only for security on this page
		dialog = new Y.Panel({
			bodyContent: '<img src="assets/loading.gif" />',
			headerContent: "Loading, please wait...",
			width      : 240,
			zIndex     : 6,
			centered   : true,
			modal      : true,
			render     : '.wait',
			visible    : true,
			// prevents user from closing dialog
			hideOn: [],
			focusOn: [],
			buttons: []
		});

		runQueue(commandsQueue);
	});
}