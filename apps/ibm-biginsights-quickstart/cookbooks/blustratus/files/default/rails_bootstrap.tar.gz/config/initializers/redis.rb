require 'resque/server'

redis_conf = Rails.root.join("config/redis", "#{Rails.env}.conf")
puts "Starting Redis... #{`redis-server "#{redis_conf}"`}"
$redis = Redis.new(:host => 'localhost', :port => 6379)
