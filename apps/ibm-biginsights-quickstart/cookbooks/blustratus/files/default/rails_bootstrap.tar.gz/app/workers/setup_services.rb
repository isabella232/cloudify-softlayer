class SetupServices
  @queue = :bootstrap

  def self.perform password, node
    # Ensure 'node' hash uses symbols as keys
    node = node.deep_symbolize_keys

    # Update LDAP bind password
    Rails.logger.info %x(
      authconfig \
        --enableldap \
        --enableldapauth \
        --ldapserver=ldap://#{node[:ldap][:ip]}:#{node[:ldap][:port]} \
        --ldapbasedn=\"dc=blustratus,dc=com\" \
        --enablemkhomedir \
        --enableforcelegacy \
        --update

      pwd=$(slappasswd -s "#{password}")
      sed -i 's,olcRootPW:.*,olcRootPW: '${pwd}',' /etc/openldap/slapd.d/cn\=config/olcDatabase\=\{2\}bdb.ldif

      service slapd restart
      sleep 10

      ldappasswd -x -D "cn=bluldap,dc=blustratus,dc=com" \
        -w "#{password}" \
        -S "uid=user1,ou=People,dc=blustratus,dc=com" \
        -s "#{password}"
      su user1 -c "#{node[:console][:install][:path]}/scripts/setupSSHKeys.sh"

      ldappasswd -x -D "cn=bluldap,dc=blustratus,dc=com" \
        -w "#{password}" \
        -S "uid=bluadmin,ou=People,dc=blustratus,dc=com" \
        -s "#{password}"
      su bluadmin -c "#{node[:console][:install][:path]}/scripts/setupSSHKeys.sh"

      ldappasswd -x -D "cn=bluldap,dc=blustratus,dc=com" \
        -w "#{password}" \
        -S "uid=bluuser,ou=People,dc=blustratus,dc=com" \
        -s "#{password}"
      su bluuser -c "#{node[:console][:install][:path]}/scripts/setupSSHKeys.sh"

      service slapd stop
      sleep 10
    )

    # Update dswebserver.properties (BLU Web Console)
    Rails.logger.info %x(
      ldap_encrypted_password=$(#{node[:console][:install][:path]}/dsutil/bin/crypt.sh "#{password}")
      #{node[:console][:install][:path]}/scripts/updatedswebserver.sh \
        -ldap.host #{node[:console][:ip]} \
        -ldap.root.passwd $ldap_encrypted_password \
        -cognosURL "https://#{node[:console][:ip]}/ibmcognos"
    )

    # Update metadb.properties (BLU Web Console)
    Rails.logger.info %x(
      su - #{node[:db2][:instance][:username]} -c "\
        cd #{node[:console][:install][:path]} && \
        bin/updatemetadb.sh \
          -dataServerType DB2LUW \
          -databaseName metadb \
          -host #{node[:db2][:ip]} \
          -port #{node[:db2][:port]} \
          -user #{node[:db2][:instance][:username]} \
          -password '#{node[:db2][:instance][:password]}'"
    )

    # Render /opt/ibm/cognos/configuration/cogstartup.xml (lib/cogstartup.xml.erb)
    File.open("#{Rails.root}/lib/cogstartup.xml", 'w') do |f|
      f.write ERB.new(File.read("#{Rails.root}/lib/cogstartup.xml.erb")).result(binding)
    end

    # Copy cogstartup.xml file to the Cognos configuration folder
    date = Time.now.strftime '%s'
    Rails.logger.info %x(
      cp -vf \
        "#{node[:cognos][:install_path]}/configuration/cogstartup.xml" \
        "#{node[:cognos][:install_path]}/configuration/cogstartup.xml.#{date}.bkp"
      cp -vf \
        "#{Rails.root}/lib/cogstartup.xml" \
        "#{node[:cognos][:install_path]}/configuration/cogstartup.xml"
    )

    # Set hostname on db2nodes.cfg
    Rails.logger.info %x(
      echo "0 `hostname` 0" > #{node[:db2][:instance][:home_dir]}/sqllib/db2nodes.cfg
    )
  end
end
