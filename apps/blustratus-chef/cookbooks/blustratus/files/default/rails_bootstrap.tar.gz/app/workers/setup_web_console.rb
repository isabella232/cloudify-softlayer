class SetupWebConsole
  @queue = :bootstrap

  def self.perform user_name, password
    bswc_config = BluBootstrap::Application.config.bswc

    # TODO: Implement exception handling
    bswc = BluStratusWebConsole.new(bswc_config[:ip_address],
    bswc_config[:port], bswc_config[:user], bswc_config[:password])
    bswc.change_password user_name, password
  end
end