# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BluBootstrap::Application.config.secret_token = 'b742a12e7379ebb7c026888207cdf13c5d67fc1962e7240c12f5986ed094224367d07ba94c5966c6ba1ce68fe3556c43e4520b35548603a07678c4a0125b3fdf'
