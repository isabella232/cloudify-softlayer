class Softlayer::BootstrapController < ApplicationController
  before_filter :validate_session, :is_ready, :authenticate_key, :authenticate_license,
                :authenticate_credentials, :check_step

  skip_before_filter :validate_session, only: ['index', 'logout']
  skip_before_filter :is_ready, only: ['index', 'logout']
  skip_before_filter :authenticate_key, only: ['index', 'key', 'logout']
  skip_before_filter :authenticate_license, only: ['index', 'key', 'license', 'logout']
  skip_before_filter :authenticate_credentials, only: ['index', 'key', 'license', 'sl_config', 'logout']
  skip_before_filter :check_step, only: ['index', 'run', 'logout']

  STORAGE_OPTIONS = {
    "20 GB" => 1033,
    "40 GB" => 1034,
    "80 GB" => 1035,
    "100 GB" => 1036,
    "120 GB" => 1037,
    "200 GB" => 1038,
    "250 GB" => 1039,
    "300 GB" => 1040,
    "350 GB" => 1041,
    "430 GB" => 1042,
    "450 GB" => 1043,
    "500 GB" => 1044,
    "700 GB" => 1045,
    "1000 GB" => 1046
  }

  def index
    Resque.remove_queue('bootstrap')
    @ready = File.exists? '/var/www/ready'

    if params[:back]
      $redis.set('current_step', 'index')
      return
    end

    if request.post?
      $redis.set('current_step', 'key')
      redirect_to action: 'key'
    end
  end

  def key
    if params[:back]
      $redis.set('current_step', 'key')
      return
    end

    if params[:upload]

      upload_directory = Rails.root.join("tmp", "uploads")
      FileUtils.mkdir_p(upload_directory) unless File.directory? upload_directory

      file_name = params[:upload][:key].original_filename
      file_path = File.join(upload_directory, file_name)

      begin
        file_content = params[:upload][:key].read
        raise ArgumentError, t('bootstrap.key.private_key.upload_error') if file_content.blank?()

        File.open(file_path, "w") { |file| file.write file_content }

        `/bin/sh #{Rails.root}/vendor/scripts/key_compare.sh #{file_path}`
        raise ArgumentError, t('bootstrap.key.private_key.no_match') if $?.exitstatus != 0

        session[:authenticated] = true

        $redis.set('current_step', 'license')
        redirect_to action: 'license'
      rescue IOError => e
        puts e.message
        flash[:error] = t('bootstrap.key.private_key.upload_error')
      rescue ArgumentError => e
        puts e.message
        flash[:error] = e.message
      end

    elsif session[:authenticated]
      $redis.set('current_step', 'license')
      redirect_to action: 'license'
    end

  end

  def license
    license_dir = Rails.root.join('vendor', 'assets', 'licenses')
    db2_license_path = File.join(license_dir, t('bootstrap.license.db2_license_file'))

    File.open(db2_license_path, "r") do |f|
      @db2_license = f.read
    end

    @license_accepted = $redis.get('license_accepted')

    if params[:back]
      $redis.set('current_step', 'license')
      return
    end

    if request.post?
      if params[:license_action] == 'accepted'
        $redis.set('license_accepted', true)
        `touch #{Rails.root}/vendor/locks/license_accepted`
        `/bin/sh #{Rails.root}/vendor/scripts/updatesshdcfg.sh`
        `/etc/init.d/sshd restart`

        $redis.set('current_step', 'sl_config')
        redirect_to action: 'sl_config'
      elsif params[:license_action] == 'declined'
        `halt -f -p`
      end
    end
  end

  def sl_config
    if params[:back]
      $redis.set('current_step', 'sl_config')
      return
    end

    if request.post?

      if params[:username].blank? || params[:access_key].blank?
        flash[:error] = t('softlayer.bootstrap.sl_config.error.cant_be_blank')

      else
        session[:username] = params[:username]
        session[:access_key] = params[:access_key]

        $redis.set('current_step', 'storage_config')
        redirect_to action: 'storage_config'
      end
    end
  end

  def storage_config
    if params[:back]
      Resque.dequeue(Softlayer::SetupIscsiDrives)
      $redis.set('current_step', 'storage_config')
      return
    end

    if request.post?
      case params[:storage_option]
        when 'new'
          $redis.set('current_step', 'create_storage')
          redirect_to action: 'create_storage'
        when 'local'
          Resque.enqueue(Softlayer::SetupIscsiDrives, session[:username], session[:access_key], 0)
          $redis.set('current_step', 'db2_config')
          redirect_to action: 'db2_config'
        else
          flash[:error] = t('softlayer.bootstrap.storage_config.error.select_device_type')
      end
    end
  end

  def create_storage
    @storage_options = STORAGE_OPTIONS

    if params[:back]
      $redis.set('current_step', 'create_storage')
      return
    end

    if request.post?
      Resque.enqueue(Softlayer::SetupIscsiDrives, session[:username], session[:access_key], params[:size].to_i)

      $redis.set('current_step', 'db2_config')
      redirect_to action: 'db2_config'
    end
  end

  def db2_config
    if params[:back]
      Resque.dequeue(SetupWebConsole)
      $redis.set('current_step', 'db2_config')
      return
    end

    if request.post?
      if [params[:user_name], params[:password], params[:password_confirmation]].any? { |p| p.blank? }
        flash[:error] = t('bootstrap.db2_config.error.missing_inputs')

      elsif params[:password] != params[:password_confirmation]
        flash[:error] = t('bootstrap.db2_config.error.non_matching_password')

      else
        Resque.enqueue(SetupWebConsole, params[:user_name], params[:password])

        $redis.set('current_step', 'apply')
        redirect_to action: 'apply'
      end
    end
  end

  def apply
    jobs = Resque.peek 'bootstrap', 0, Resque.size('bootstrap')
    jobs = [jobs] if !jobs.is_a? Array

    iscsi_drive = jobs.select { |j| j["class"] == "Softlayer::SetupIscsiDrives" }
    db2_user = jobs.select { |j| j["class"] == "SetupWebConsole" }

    if iscsi_drive.empty? || db2_user.empty?
      Resque.remove_queue('bootstrap')
      $redis.set('current_step', 'storage_config')
      redirect_to action: 'storage_config'
      return
    end

    @iscsi_size = STORAGE_OPTIONS.invert[iscsi_drive.first["args"][2]]
    @db2_user = { user_name: db2_user.first["args"][0], password: db2_user.first["args"][1] }
  end

  def run
    logger.info '>> Start Running...'

    while Resque.size('bootstrap') > 0
      job = Resque.pop('bootstrap')
      logger.info ">> Running job: #{job}"

      begin
        obj = job["class"].constantize
        obj.perform(*job["args"])
      rescue => e
        logger.info e.message
        logger.info e.inspect

        render json: { error: e.message }, status: 500
        return
      end
    end

    $redis.set('current_step', 'done')
    render text: "OK"
  end

  def done
    exec("/bin/bash #{Rails.root}/vendor/scripts/start_web_console.sh")
    render text: "OK"
  end

private
  def validate_session
    session_id = request.session_options[:id]
    saved_session_id = $redis.get('session_id')

    if session_id.blank?
      redirect_to action: 'index'
      return
    end

    if saved_session_id.blank?
      $redis.set('session_id', session_id)
      $redis.expire('session_id', 300)
      saved_session_id = session_id
    end

    if session_id != saved_session_id
      flash[:notice] = t('bootstrap.error.configuration_in_process')
      redirect_to action: 'index'
    end
  end

  def is_ready
    if !File.exists? '/var/www/ready'
      $redis.set('current_step', 'index')
      redirect_to action: 'index'
    end
  end

  def authenticate_key
    if !session[:authenticated]
      $redis.set('current_step', 'key')
      redirect_to action: 'key'
    end
  end

  def authenticate_license
    if !$redis.get('license_accepted')
      $redis.set('current_step', 'license')
      redirect_to action: 'license'
    end
  end

  def authenticate_credentials
    if [session[:username], session[:access_key]].any? { |s| s.blank? }
      $redis.set('current_step', 'sl_config')
      redirect_to action: 'sl_config'
    end
  end

  def check_step
    current_step = $redis.get('current_step')

    if !current_step
      $redis.set('current_step', 'index')
      redirect_to action: 'index'
      return
    end

    if current_step != params[:action] && !params[:back]
      redirect_to action: current_step
    end
  end

end
