module SoftlayerBootstrapScripts
  def self.get_iscsi_devices(username=$SL_API_USERNAME, password=$SL_API_KEY)
    $SL_API_USERNAME = username
    $SL_API_KEY = password
    account_service = SoftLayer::Service.new("SoftLayer_Account")
    account_service.getIscsiNetworkStorage
  end

  def self.iscsi_device_for_id username, password, id
    devices = get_iscsi_devices(username, password)
    devices.each do |device|
      return device if device["id"] == id
    end

    return {}
  end

  def self.order(username, password, size=1033)
    $SL_API_USERNAME = username
    $SL_API_KEY = password
    ids_before = get_iscsi_devices.collect { |d| d["id"] }
    order_iscsi(size)
    ids_after = ids_before
    while ids_before == ids_after
      ids_after = get_iscsi_devices.collect { |d| d["id"] }
      sleep 5
    end
    new_id = (ids_after - ids_before).first
    get_iscsi_devices.detect { |d| d["id"] == new_id }
  end

  def self.mount_drives drives=[]
    usernames = %x(for user in `find /sys/devices/platform/host* -name username`; do cat $user; done)
    devs = %x(for user in `find /sys/devices/platform/host* -name block`; do ls $user; done)

    user_dev_hash = usernames.split.zip(devs.split).inject({}) { |h,e| h[e[0]] = e[1]; h }

    drives.each do |drive|
      device = user_dev_hash[drive[:username]]
      if drive[:format]
        %x(mkfs.ext4 -F /dev/#{device})
      end

      %x(mkdir -p #{drive[:mount_dir]})
      %x(mount /dev/#{device} #{drive[:mount_dir]})

      %x(chkconfig iscsi on)
      %x(echo "/dev/#{device} #{drive[:mount_dir]} ext4 _netdev 0 0" >> /etc/fstab)
    end
  end

  private
  def self.locations(region=nil)
    location_service = SoftLayer::Service.new("SoftLayer_Location_Datacenter")
    locs = location_service.getDatacenters
    return locs.detect { |dc| dc["longName"] =~ /#{region}/ } unless region.nil?
    locs
  end

  def self.order_iscsi(device_size_id, location="Washington")
    softLayer_product_order = SoftLayer::Service.new( "SoftLayer_Product_Order")
    location_id = locations(location)["id"]
    $product_order = {
      "complexType" => "SoftLayer_Container_Product_Order",
      "location" => location_id,
      "packageId" => 0,
      "prices" => [ { "id" => device_size_id } ] #20GB ISCSI
    }
    begin
      result = softLayer_product_order.placeOrder($product_order)
      puts "The order was verified successfully"
    rescue => error_reason
      puts "The order could not be verified by the server #{error_reason}"
    end
  end
end