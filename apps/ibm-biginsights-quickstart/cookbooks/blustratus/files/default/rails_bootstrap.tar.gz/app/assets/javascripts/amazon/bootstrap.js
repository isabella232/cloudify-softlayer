// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
$(function() {
	$('#index-next-button').click(function() {
		$this = $(this);
		$this.attr('disabled','disabled');
		window.location = 'license';
	});

	$('#decline-license-button').click(function() {
		if (confirm(I18n.bootstrap.license.decline_confirmation)) {
			$('#license_action').val('declined');
			$('form').submit();
		}
	});

	$('#accept-license-button').click(function() {
		if ($('#accept_db2').is(':checked')) {
			$('#license_action').val('accepted');
			$('form').submit();
		} else {
			alert(I18n.bootstrap.license.check_license_agreement);
		}
	});

	$('#use-iops').click(function() {
		if ($('#use-iops').prop('checked')) {
			$('#iops-count').show();
		} else {
			$('#iops-count').hide();
		}
	});

	$('#db2-config-next-button').click(configureDB2);

	$('#load-web-console-button').click(function() {
		$this = $(this);
		$this.attr('disabled','disabled');
		window.location = window.location.protocol + '//' + window.location.hostname + ':8443';
	});
});