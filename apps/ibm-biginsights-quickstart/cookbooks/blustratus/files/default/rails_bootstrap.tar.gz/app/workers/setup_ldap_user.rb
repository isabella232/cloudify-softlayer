class SetupLdapUser
  @queue = :bootstrap

  def self.perform user_name, password
    console_config = BluBootstrap::Application.config.bootstrap[:console]

    # TODO: Implement exception handling
    console = BluStratusWebConsole.new(console_config[:ip],
      console_config[:port], console_config[:user], console_config[:password])
    console.change_password user_name, password

    console_path = console_config[:install][:path]
    Rails.logger.info %x(
      su #{user_name} -c "#{console_path}/scripts/setupSSHKeys.sh"
    )
  end
end
