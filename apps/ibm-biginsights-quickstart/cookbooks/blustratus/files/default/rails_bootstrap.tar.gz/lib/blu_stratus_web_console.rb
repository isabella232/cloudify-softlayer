class BluStratusWebConsole

  HEADERS = { accept: :json, content_type: :json }

  attr_reader :endpoint

  def initialize ip_address, port, user, password
    self.user = user
    self.password = password
    self.endpoint = "https://#{ip_address}:#{port}/console"

    self.user_service = "#{endpoint}/blushiftservices/BluShiftHttp.do"
    self.login_service = "#{endpoint}/loginService"
    self.logout_service = "#{endpoint}/dsconsolelib/shared/login/logout.jsp"

    self.headers = HEADERS
    self.cookies = login.cookies

    ObjectSpace.define_finalizer self, method(:finalize)
  end


  def add_user user_id, user_password
    params = { cmd: 'addUser', userid: user_id, password: user_password, syncMode: true }
    user_service_call! params
  end

  def change_password user_id, user_password
    params = { cmd: 'modifyUserPassword', userid: user_id, password: user_password }
    user_service_call! params
  end

private

  attr_writer :endpoint
  attr_accessor :user, :password, :user_service, :login_service,
    :logout_service, :cookies, :headers

  def user_service_call! params
    RestClient.post(@user_service, params,
      { headers: @headers, cookies: @cookies }) do |response, request, result, &block|
      resp = JSON.parse(response.to_s) rescue response.inspect
      raise resp unless response.code == 200
    end
  end

  def login
    response = RestClient.post(@login_service,
      { j_username: @user, j_password: @password }, { headers: @headers })
    response.cookies.delete 'Path'
    response
  end

  def logout!
    RestClient.post(@logout_service, {},
      { headers: @headers, cookies: @cookies }) do |response, request, result, &block|
      resp = JSON.parse(response.to_s) rescue response.inspect
      raise resp unless [200, 302].include?(response.code)
    end
  end

  def finalize
    logout!
  end

end
